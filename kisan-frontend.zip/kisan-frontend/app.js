/* ---------- CONFIG ----------
   Point API_URL at your backend. Expected endpoints:
   GET  {API_URL}/prices?mandi=NAME  -> [{crop, emoji, min, max, modal, retail, change}]
        (min/max/modal in Rs per quintal, retail in Rs per kg, change in %)
   POST {API_URL}/assistant  body {message, mandi, lang, prices} -> {reply}
   Leave API_URL empty to use the built-in sample data. */
const API_URL = "";

const MANDIS = ["Bowenpally, Hyderabad", "Warangal", "Nizamabad", "Guntur", "Kurnool"];
const MANDI_FACTOR = {"Bowenpally, Hyderabad":1, "Warangal":.97, "Nizamabad":1.03, "Guntur":1.02, "Kurnool":.99};

const I18N = {
  en:{title:"Kisan Mandi Dashboard",search:"Search crop…",prices:"Today’s prices",crop:"Crop",min:"Min",max:"Max",modal:"Modal",retail:"Retail/kg",trend:"Trend",compare:"Modal price comparison",note:"Mandi: ₹ per quintal · Retail: ₹ per kg",ask:"Ask the assistant",send:"Send",ph:"e.g. Tomato price? Best mandi for chilli?",tracked:"Crops tracked",gain:"Top gainer",fall:"Biggest fall",gap:"Retail vs mandi",hello:"Namaste! 🙏 Ask me a crop price or where to sell.",none:"No crop found.",sample:"Sample data (no API connected)",live:"Live data",err:"Could not load prices, showing sample data"},
  hi:{title:"किसान मंडी डैशबोर्ड",search:"फसल खोजें…",prices:"आज के भाव",crop:"फसल",min:"न्यूनतम",max:"अधिकतम",modal:"औसत भाव",retail:"खुदरा/किलो",trend:"रुझान",compare:"औसत भाव तुलना",note:"मंडी: ₹ प्रति क्विंटल · खुदरा: ₹ प्रति किलो",ask:"सहायक से पूछें",send:"भेजें",ph:"जैसे: टमाटर का भाव?",tracked:"फसलें",gain:"सबसे ज़्यादा बढ़त",fall:"सबसे ज़्यादा गिरावट",gap:"खुदरा बनाम मंडी",hello:"नमस्ते! 🙏 फसल का भाव या कहाँ बेचें, पूछिए।",none:"कोई फसल नहीं मिली।",sample:"नमूना डेटा (API जुड़ा नहीं)",live:"लाइव डेटा",err:"भाव लोड नहीं हुए, नमूना डेटा दिख रहा है"},
  te:{title:"రైతు మండి డాష్‌బోర్డ్",search:"పంట వెతకండి…",prices:"నేటి ధరలు",crop:"పంట",min:"కనిష్ఠ",max:"గరిష్ఠ",modal:"సగటు ధర",retail:"రిటైల్/కిలో",trend:"ధోరణి",compare:"సగటు ధర పోలిక",note:"మండి: ₹ క్వింటాల్‌కు · రిటైల్: ₹ కిలోకు",ask:"సహాయకుడిని అడగండి",send:"పంపండి",ph:"ఉదా: టమాటా ధర ఎంత?",tracked:"పంటలు",gain:"అత్యధిక పెరుగుదల",fall:"అత్యధిక తగ్గుదల",gap:"రిటైల్ vs మండి",hello:"నమస్తే! 🙏 పంట ధర లేదా ఎక్కడ అమ్మాలో అడగండి.",none:"పంట దొరకలేదు.",sample:"నమూనా డేటా (API కనెక్ట్ కాలేదు)",live:"లైవ్ డేటా",err:"ధరలు లోడ్ కాలేదు, నమూనా డేటా చూపిస్తున్నాం"}
};

const SAMPLE = [
  ["Paddy","🌾",2100,2450,2300,38,.8],["Maize","🌽",2050,2400,2250,32,-1.2],["Cotton","☁️",6600,7400,7000,0,1.5],
  ["Red Chilli","🌶️",12500,15800,14000,220,3.4],["Turmeric","🟡",12800,14600,13500,190,2.1],["Tomato","🍅",1600,2900,2200,38,-6.5],
  ["Onion","🧅",1400,2200,1800,30,-2.3],["Potato","🥔",1700,2300,2000,28,.4],["Groundnut","🥜",5700,6600,6200,110,1.1],
  ["Soybean","🫘",4300,4900,4600,70,-.6],["Wheat","🌾",2250,2600,2400,34,.3],["Tur Dal","🫛",7000,8000,7500,150,1.9]
];

const $ = id => document.getElementById(id);
const inr = n => "₹" + Math.round(n).toLocaleString("en-IN");
let state = {lang:"en", rows:[], live:false, error:false};
const t = k => I18N[state.lang][k];

function sampleRows(mandi){
  const k = MANDI_FACTOR[mandi] || 1;
  return SAMPLE.map(d => ({crop:d[0], emoji:d[1], min:d[2]*k, max:d[3]*k, modal:d[4]*k, retail:d[5], change:d[6]}));
}

async function loadPrices(){
  const mandi = $("mandi").value;
  state.live = false; state.error = false;
  if (API_URL){
    try {
      const r = await fetch(`${API_URL}/prices?mandi=${encodeURIComponent(mandi)}`);
      if (!r.ok) throw new Error(r.status);
      state.rows = await r.json(); state.live = true;
    } catch (e) { state.rows = sampleRows(mandi); state.error = true; }
  } else state.rows = sampleRows(mandi);
  render();
}

function applyLang(){
  document.documentElement.lang = state.lang;
  document.querySelectorAll("[data-i18n]").forEach(el => el.textContent = t(el.dataset.i18n));
  document.querySelectorAll("[data-ph]").forEach(el => el.placeholder = t(el.dataset.ph));
  $("msg").placeholder = t("ph");
  $("status").textContent = state.error ? t("err") : state.live ? t("live") : t("sample");
}

function render(){
  applyLang();
  const s = $("q").value.toLowerCase();
  const list = state.rows.filter(d => d.crop.toLowerCase().includes(s));
  $("rows").innerHTML = list.map(d => `
    <tr class="border-b last:border-0 dark:border-slate-700">
      <td class="py-2 font-medium">${d.emoji||""} ${d.crop}</td>
      <td>${inr(d.min)}</td><td>${inr(d.max)}</td><td class="font-semibold">${inr(d.modal)}</td>
      <td>${d.retail ? "₹"+Math.round(d.retail) : "—"}</td>
      <td class="${d.change>=0?"text-green-600":"text-red-600"} font-medium">${d.change>=0?"▲":"▼"} ${Math.abs(d.change)}%</td>
    </tr>`).join("") || `<tr><td colspan="6" class="py-4 text-slate-500">${t("none")}</td></tr>`;

  const all = state.rows;
  if (all.length){
    const sorted = [...all].sort((a,b) => b.change - a.change);
    const up = sorted[0], down = sorted[sorted.length-1];
    const withR = all.filter(d => d.retail);
    const gap = withR.reduce((a,d) => a + d.retail/(d.modal/100), 0) / (withR.length||1);
    const card = (l,v,sub,c="") => `<div class="bg-white dark:bg-slate-800 rounded-xl shadow p-3"><p class="text-xs text-slate-500">${l}</p><p class="text-lg font-bold ${c}">${v}</p><p class="text-xs text-slate-500">${sub}</p></div>`;
    $("cards").innerHTML =
      card(t("tracked"), all.length, $("mandi").value) +
      card(t("gain"), `${up.emoji||""} ${up.crop}`, `▲ ${up.change}%`, "text-green-600") +
      card(t("fall"), `${down.emoji||""} ${down.crop}`, `▼ ${Math.abs(down.change)}%`, "text-red-600") +
      card(t("gap"), gap.toFixed(1)+"×", "");
  }
  const max = Math.max(...list.map(d => d.modal), 1);
  $("bars").innerHTML = list.map(d => `
    <div><div class="flex justify-between text-xs"><span>${d.emoji||""} ${d.crop}</span><span>${inr(d.modal)}</span></div>
    <div class="h-2 rounded bg-slate-200 dark:bg-slate-700"><div class="h-2 rounded bg-green-600" style="width:${d.modal/max*100}%"></div></div></div>`).join("");
}

/* ---------- Assistant ---------- */
function say(text, me){
  const b = document.createElement("div");
  b.className = "max-w-[85%] px-3 py-2 rounded-lg " + (me ? "ml-auto bg-green-700 text-white" : "bg-slate-100 dark:bg-slate-700");
  b.textContent = text; $("chat").appendChild(b); $("chat").scrollTop = 1e9;
}
function localAnswer(q){
  q = q.toLowerCase();
  const c = state.rows.find(d => q.includes(d.crop.toLowerCase().split(" ")[0]));
  if (!c) return "Try: “Tomato price?” or “Should I sell onion now?”";
  const tip = c.change > 1 ? "Prices are rising; hold a few days if you can store safely."
    : c.change < -2 ? "Prices are falling; sell soon if it spoils easily." : "Prices are steady; sell as you need cash.";
  return `${c.crop}: modal ${inr(c.modal)}/quintal (${inr(c.min)}–${inr(c.max)}). ${c.retail ? "Retail ≈ ₹"+Math.round(c.retail)+"/kg. " : ""}${tip} Confirm at the mandi before travelling.`;
}
async function ask(){
  const v = $("msg").value.trim(); if (!v) return;
  say(v, true); $("msg").value = "";
  if (API_URL){
    try {
      const r = await fetch(`${API_URL}/assistant`, {method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({message:v, mandi:$("mandi").value, lang:state.lang, prices:state.rows})});
      const j = await r.json(); return say(j.reply);
    } catch (e) { /* fall through to local answer */ }
  }
  say(localAnswer(v));
}

/* ---------- Init ---------- */
MANDIS.forEach(m => $("mandi").add(new Option(m, m)));
$("lang").onchange = e => { state.lang = e.target.value; render(); };
$("mandi").onchange = loadPrices;
$("q").oninput = render;
$("send").onclick = ask;
$("msg").onkeydown = e => { if (e.key === "Enter") ask(); };
say(t("hello"));
loadPrices();
